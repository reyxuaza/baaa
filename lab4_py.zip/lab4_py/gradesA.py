#!/bin/python3
import csv

with open ("grades.csv", newline = '') as plik:
	read= csv.DictReader(plik, delimiter= ",")
				
	
	for row in read:
		suma=0
		print(row['Last name']+" "+row['First name'])
		if(float(row['Test1']) < 0):
			suma+=0
		else:
			suma+=float(row['Test1'])
		if(float(row['Test2']) < 0):
			suma+=0
		else:
			suma+=float(row['Test2']) 
		if(float(row['Test3']) < 0):
			suma+=0
		else:
			suma+=float(row['Test3']) 
		if(float(row['Test4']) < 0):
			suma+=0
		else:
			suma+=float(row['Test4']) 
		if(float(row['Final']) < 0):
			suma+=0
		else:
			suma+=float(row['Final']) 
		srednia=suma/5
		print(srednia)
		
