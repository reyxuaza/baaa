#!/bin/python3
import csv 


with open ("grades.csv", newline = '') as plik:
	read= csv.DictReader(plik, delimiter= ",")
	#linie=len(list(read))
	#for i in range (0,5): #zrobie lopatologicznie
	suma=0
	
	for row in read:
		if(float(row['Test1']) > 0):
			suma+=float(row['Test1'])
			
	print('srednia testu1: ')
	print(suma/16) #linie nie dzialaja
with open ("grades.csv", newline = '') as plik:
	read= csv.DictReader(plik, delimiter= ",")
	suma=0
	for row in read:
		if(float(row['Test2']) > 0):
			suma+=float(row['Test2'])
					
	print('srednia testu2: ')
	print(suma/16) 
with open ("grades.csv", newline = '') as plik:
	read= csv.DictReader(plik, delimiter= ",")
	suma=0
	
	for row in read:
		if(float(row['Test3']) > 0):
			suma+=float(row['Test3'])
			
	print('srednia testu3: ')
	print(suma/16) #linie nie dzialaja
with open ("grades.csv", newline = '') as plik:
	read= csv.DictReader(plik, delimiter= ",")
	suma=0
	
	for row in read:
		if(float(row['Test4']) > 0):
			suma+=float(row['Test4'])
			
	print('srednia testu4: ')
	print(suma/16) #linie nie dzialaja
with open ("grades.csv", newline = '') as plik:
	read= csv.DictReader(plik, delimiter= ",")
	suma=0
	
	for row in read:
		if(float(row['Final']) > 0):
			suma+=float(row['Final'])
			
	print('srednia finalnego testu: ')
	print(suma/16) #linie nie dzialaja
	
		
#wyglada to okropnie, ale dziala
	
		
